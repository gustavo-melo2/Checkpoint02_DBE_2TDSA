package br.com.fiap.epictask.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data // Adiciona os getters, setters, toString, equals e hashcode
@Entity
@Table(name = "USER_EPICTASK")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;

	@NotBlank(message = "O campo nome é obrigatório.")
	private String name;
	
	@NotBlank(message = "O campo e-mail é obrigatório.")
	@Email(message = "Coloque um email valido!")
	private String email;
	
	@Size(min = 8, message = "O campo senha deve ter no minimo 8 caracteres.")
	private String password;
	
	
}
