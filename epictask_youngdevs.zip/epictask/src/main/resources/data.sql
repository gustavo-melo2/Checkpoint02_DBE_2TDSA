CREATE TABLE TASK(
	id int PRIMARY KEY auto_increment,
	title varchar(200),
	description TEXT,
	points int
);

INSERT INTO task VALUES (1, 'Criar Banco de Dados', 'Criação do banco de dados na nuvem', 150);
INSERT INTO task VALUES (2, 'Prototipação da aplicação', 'Definição do prototipo da interface grafica', 100);
INSERT INTO task VALUES (3, 'Criar API REST', 'Criação de API para serviços de endpoint', 250);